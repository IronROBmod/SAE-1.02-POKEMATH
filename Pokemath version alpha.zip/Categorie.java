enum Categorie{
    PHYSIQUE, SPECIALE, AUTRE;
}