# SAE-1.02-POKEMATH

Auteurs : Théo Cattaneo, Hocine Chebout

Pokemath est un logiciel éducatif dans lequel un élève doit faire des calculs dans un colbat Pokemon

Ouvrez un terminal dans le dossier contenant les fichiers de code puis :

Pour compliler le programme :
ijavac PokeMath.java

Pour lancer le Programme :
ijava PokeMath