class Move{
    String name;
    Element element;
    int power;
    Categorie categorie;
    String description;
}