public class Pokemon{
    String name;
    int niveau;
    int pv;
    int attack;
    int attackSpe;
    int defense;
    int defenseSpe;
    int vitesse;
    Element type1;
    Element type2;
    Move[] attaques;
}